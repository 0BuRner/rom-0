using System;
using System.Collections.Generic;
using System.IO;
using System.Windows.Forms;
using Clifton.Collections.Generic;

namespace ZyXEL_Firmware
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            openFileDialog1.FileName = "spt.dat";
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                File.WriteAllBytes(openFileDialog1.FileName + ".decompressed", Decompress(openFileDialog1.FileName));
            }
        }

        private static byte[] Decompress(string path)
        {
            var result = new List<byte>();
            byte[] fileData = File.ReadAllBytes(path);
            int index = 0;
            int unknown = fileData[index++] << 24 | fileData[index++] << 16 | fileData[index++] << 8 | fileData[index++];
            int majorVersion = fileData[index++] << 8 | fileData[index++];
            int minorVersion = fileData[index++] << 8 | fileData[index++];
            int blockSize = fileData[index++] << 24 | fileData[index++] << 16 | fileData[index++] << 8 |
                            fileData[index++];
            while (index < fileData.Length)
            {
                int orgSize = fileData[index++] << 8 | fileData[index++];
                int rawSize = fileData[index++] << 8 | fileData[index++];
                var compressedData = new byte[rawSize];
                Array.Copy(fileData, index, compressedData, 0, compressedData.Length);
                byte[] decompressed = Decompress(compressedData);
                result.AddRange(decompressed);
                index += rawSize;
            }
            return result.ToArray();
        }

        private static byte[] Decompress(byte[] bytes)
        {
            var result = new List<byte>();
            var window = new CircularList<byte>(2048);
            var reader = new BitReader(bytes);
            while (true)
            {
                bool bit = reader.ReadBit();
                if (!bit)
                {
                    byte character = reader.ReadByte();
                    result.Add(character);
                    window.Add(character);
                }
                else
                {
                    int offset;
                    bit = reader.ReadBit();
                    if (bit)
                    {
                        offset = reader.ReadBits(7);
                        if (offset == 0)
                        {
                            //end of file
                            break;
                        }
                    }
                    else
                    {
                        offset = reader.ReadBits(11);
                    }
                    int len;
                    int lenField = reader.ReadBits(2);
                    if (lenField < 3)
                    {
                        len = lenField + 2;
                    }
                    else
                    {
                        lenField <<= 2;
                        lenField += reader.ReadBits(2);
                        if (lenField < 15)
                        {
                            len = (lenField & 0x0f) + 5;
                        }
                        else
                        {
                            int lenCounter = 0;
                            lenField = reader.ReadBits(4);
                            while (lenField == 15)
                            {
                                lenField = reader.ReadBits(4);
                                lenCounter++;
                            }
                            len = 15*lenCounter + 8 + lenField;
                        }
                    }
                    for (int i = 0; i < len; i++)
                    {
                        byte character = window.GetValue(-offset);
                        result.Add(character);
                        window.Add(character);
                    }
                }
            }


            return result.ToArray();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                var file = new ConfigFile(openFileDialog1.FileName);
                foreach (Block block in file.blocks)
                {
                    foreach (DirEntry entry in block.DirEntries)
                    {
                        File.WriteAllBytes(entry.Name, block.GetData(entry));
                    }
                }
            }
        }
    }
}